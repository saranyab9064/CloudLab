from mininet.topo import Topo
from mininet.net import Mininet
from mininet.link import TCLink
from mininet.util import dumpNodeConnections
from mininet.log import setLogLevel
from mininet.cli import CLI

class MyTopo(Topo):
	
	def __init__(self):
		Topo.__init__(self)
		
		s1 = self.addSwitch('s1')
		s2 = self.addSwitch('s2')
		s3 = self.addSwitch('s3')
		s4 = self.addSwitch('s4')
		
		h1 = self.addHost('h1')
		h2 = self.addHost('h2')
		
		self.addLink(h1, s1)
		self.addLink(h2, s2)
		
		self.addLink(s1, s3, delay='1ms')
		self.addLink(s2, s3, delay='1ms')
		self.addLink(s3, s4, delay='1ms')
		self.addLink(s4, s1, delay='1ms')

topos = { 'mytopo': (lambda: MyTopo()) }