#~/bin/bash
kill `pgrep ryu-manager`
